"""
Extensions for the MNE library.
"""
