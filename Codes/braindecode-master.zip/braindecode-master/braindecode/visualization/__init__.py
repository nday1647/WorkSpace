"""
Functions for visualisations, especially of the ConvNets.
"""
