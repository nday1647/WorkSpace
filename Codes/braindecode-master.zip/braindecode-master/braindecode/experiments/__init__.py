"""
Convenience classes for experiments, including monitoring and stop criteria.
"""
