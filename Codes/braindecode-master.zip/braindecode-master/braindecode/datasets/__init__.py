"""
Loader code for some datasets.
"""