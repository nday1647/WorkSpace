braindecode\.datasets package
=============================

.. automodule:: braindecode.datasets
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

braindecode\.datasets\.bbci module
----------------------------------

.. automodule:: braindecode.datasets.bbci
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.datasets\.bcic\_iv\_2a module
------------------------------------------

.. automodule:: braindecode.datasets.bcic_iv_2a
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.datasets\.multiple module
--------------------------------------

.. automodule:: braindecode.datasets.multiple
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.datasets\.sensor\_positions module
-----------------------------------------------

.. automodule:: braindecode.datasets.sensor_positions
    :members:
    :undoc-members:
    :show-inheritance:


