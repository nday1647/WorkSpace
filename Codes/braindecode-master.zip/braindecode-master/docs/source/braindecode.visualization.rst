braindecode\.visualization package
==================================

.. automodule:: braindecode.visualization
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

braindecode\.visualization\.perturbation module
-----------------------------------------------

.. automodule:: braindecode.visualization.perturbation
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.visualization\.plot module
---------------------------------------

.. automodule:: braindecode.visualization.plot
    :members:
    :undoc-members:
    :show-inheritance:


