braindecode\.mne\_ext package
=============================

.. automodule:: braindecode.mne_ext
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

braindecode\.mne\_ext\.signalproc module
----------------------------------------

.. automodule:: braindecode.mne_ext.signalproc
    :members:
    :undoc-members:
    :show-inheritance:


