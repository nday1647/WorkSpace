braindecode\.torch\_ext package
===============================

.. automodule:: braindecode.torch_ext
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

braindecode\.torch\_ext\.constraints module
-------------------------------------------

.. automodule:: braindecode.torch_ext.constraints
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.torch\_ext\.functions module
-----------------------------------------

.. automodule:: braindecode.torch_ext.functions
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.torch\_ext\.init module
------------------------------------

.. automodule:: braindecode.torch_ext.init
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.torch\_ext\.losses module
--------------------------------------

.. automodule:: braindecode.torch_ext.losses
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.torch\_ext\.modules module
---------------------------------------

.. automodule:: braindecode.torch_ext.modules
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.torch\_ext\.util module
------------------------------------

.. automodule:: braindecode.torch_ext.util
    :members:
    :undoc-members:
    :show-inheritance:


