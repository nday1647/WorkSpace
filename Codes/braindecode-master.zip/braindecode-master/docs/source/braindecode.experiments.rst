braindecode\.experiments package
================================

.. automodule:: braindecode.experiments
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

braindecode\.experiments\.experiment module
-------------------------------------------

.. automodule:: braindecode.experiments.experiment
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.experiments\.monitors module
-----------------------------------------

.. automodule:: braindecode.experiments.monitors
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.experiments\.stopcriteria module
---------------------------------------------

.. automodule:: braindecode.experiments.stopcriteria
    :members:
    :undoc-members:
    :show-inheritance:


