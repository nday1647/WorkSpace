braindecode\.models package
===========================

.. automodule:: braindecode.models
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

braindecode\.models\.deep4 module
---------------------------------

.. automodule:: braindecode.models.deep4
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.models\.eegnet module
----------------------------------

.. automodule:: braindecode.models.eegnet
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.models\.shallow\_fbcsp module
------------------------------------------

.. automodule:: braindecode.models.shallow_fbcsp
    :members:
    :undoc-members:
    :show-inheritance:

braindecode\.models\.util module
--------------------------------

.. automodule:: braindecode.models.util
    :members:
    :undoc-members:
    :show-inheritance:


