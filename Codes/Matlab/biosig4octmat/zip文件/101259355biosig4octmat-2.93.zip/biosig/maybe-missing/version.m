function v = version() 
% version information for FreeMat 
%  returns '3.2'

v = '3.2';
