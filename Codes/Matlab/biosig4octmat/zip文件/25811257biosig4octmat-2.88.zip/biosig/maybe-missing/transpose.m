function x = transpose(x)
% needed by svmtrain, svmpredict
 x = x.';
endfunction 