from CSPTrain import CSPTrain
from CSPSpatialFilter import CSPSpatialFilter