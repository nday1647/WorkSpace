ei_net
======

E-I Net is a spiking neural network simulation and a general-purpose spiking neural circuit simulator