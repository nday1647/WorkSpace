
def get_version():
    return '0.5'