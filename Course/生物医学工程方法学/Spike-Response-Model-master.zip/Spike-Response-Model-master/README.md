# FeedForward-Spiking-Neural-Network
multilayer spiking neural network with SRM0 model
